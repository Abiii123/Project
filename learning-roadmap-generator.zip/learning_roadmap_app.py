import streamlit as st
import json
import datetime

# Page configuration
st.set_page_config(
    page_title="Learning Roadmap Generator",
    page_icon="🗺️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load roadmaps data
@st.cache_data
def load_roadmaps_data():
    try:
        with open('roadmaps_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        st.error("Roadmaps data file not found. Please ensure roadmaps_data.json exists.")
        return {}

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .phase-container {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 5px solid #1f77b4;
    }
    .phase-title {
        color: #1f77b4;
        font-size: 1.3rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
    .topic-item {
        background-color: white;
        padding: 0.5rem;
        margin: 0.3rem 0;
        border-radius: 5px;
        border-left: 3px solid #ff7f0e;
    }
    .resource-item {
        background-color: #e8f4fd;
        padding: 0.3rem 0.5rem;
        margin: 0.2rem 0;
        border-radius: 3px;
    }
    .stats-container {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Header
    st.markdown('<h1 class="main-header">🗺️ Learning Roadmap Generator</h1>', unsafe_allow_html=True)
    st.markdown("### Generate personalized learning paths for your tech journey!")

    # Load data
    roadmaps_data = load_roadmaps_data()

    if not roadmaps_data:
        st.stop()

    # Sidebar for user input
    st.sidebar.title("🎯 Customize Your Roadmap")

    # Subject selection
    subject = st.sidebar.selectbox(
        "Choose your learning subject:",
        options=list(roadmaps_data.keys()),
        help="Select the subject you want to learn"
    )

    # Experience level
    experience_level = st.sidebar.selectbox(
        "What's your current experience level?",
        options=["Complete Beginner", "Some Experience", "Intermediate", "Advanced"],
        help="This helps us tailor the roadmap to your level"
    )

    # Learning intensity
    learning_intensity = st.sidebar.selectbox(
        "How many hours per week can you dedicate?",
        options=["5-10 hours/week (Part-time)", "10-20 hours/week (Regular)", "20+ hours/week (Intensive)"],
        help="Choose your learning intensity"
    )

    # Learning goals
    goals = st.sidebar.multiselect(
        "What are your learning goals?",
        options=[
            "Get a job in tech",
            "Improve current skills",
            "Build personal projects",
            "Prepare for interviews",
            "Career transition",
            "Academic purposes"
        ],
        default=["Improve current skills"],
        help="Select all that apply"
    )

    # Generate roadmap button
    if st.sidebar.button("🚀 Generate My Roadmap", type="primary"):
        generate_roadmap(roadmaps_data, subject, experience_level, learning_intensity, goals)

def generate_roadmap(roadmaps_data, subject, experience_level, learning_intensity, goals):
    """Generate and display the personalized roadmap"""

    roadmap = roadmaps_data[subject]

    # Display roadmap header
    col1, col2 = st.columns([2, 1])

    with col1:
        st.header(f"📚 {roadmap['title']}")
        st.write(f"**Description:** {roadmap['description']}")

        # Adjust timeline based on experience and intensity
        timeline_multiplier = get_timeline_multiplier(experience_level, learning_intensity)
        adjusted_time = adjust_timeline(roadmap['estimated_time'], timeline_multiplier)

        st.write(f"**Estimated Time:** {adjusted_time}")
        st.write(f"**Difficulty Level:** {roadmap['difficulty']}")

    with col2:
        # Stats container
        stats_html = f"""
        <div class="stats-container">
            <h3>📊 Your Plan</h3>
            <p><strong>Subject:</strong> {subject}</p>
            <p><strong>Level:</strong> {experience_level}</p>
            <p><strong>Intensity:</strong> {learning_intensity}</p>
            <p><strong>Timeline:</strong> {adjusted_time}</p>
        </div>
        """
        st.markdown(stats_html, unsafe_allow_html=True)

    st.markdown("---")

    # Display phases
    st.header("📋 Learning Phases")

    for i, phase in enumerate(roadmap['phases'], 1):
        # Adjust phase duration
        adjusted_duration = adjust_phase_duration(phase['duration'], timeline_multiplier)

        phase_html = f"""
        <div class="phase-container">
            <div class="phase-title">Phase {i}: {phase['phase']}</div>
            <p><strong>Duration:</strong> {adjusted_duration}</p>
        </div>
        """
        st.markdown(phase_html, unsafe_allow_html=True)

        # Display topics
        st.write("**Topics to Cover:**")
        for topic in phase['topics']:
            st.markdown(f'<div class="topic-item">• {topic}</div>', unsafe_allow_html=True)

        # Add personalized tips based on experience level
        tips = get_personalized_tips(experience_level, phase['phase'])
        if tips:
            st.info(f"💡 **Tip for {experience_level}s:** {tips}")

        st.markdown("<br>", unsafe_allow_html=True)

    # Resources section
    st.header("📖 Recommended Resources")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🔗 General Resources")
        for resource in roadmap['resources']:
            st.markdown(f'<div class="resource-item">📌 {resource}</div>', unsafe_allow_html=True)

    with col2:
        st.subheader("🎯 Goal-Specific Resources")
        goal_resources = get_goal_specific_resources(subject, goals)
        for resource in goal_resources:
            st.markdown(f'<div class="resource-item">🎯 {resource}</div>', unsafe_allow_html=True)

    # Progress tracking section
    st.markdown("---")
    st.header("📈 Track Your Progress")

    progress_col1, progress_col2 = st.columns(2)

    with progress_col1:
        st.subheader("Phase Completion")
        for i, phase in enumerate(roadmap['phases'], 1):
            completed = st.checkbox(f"Phase {i}: {phase['phase']}", key=f"phase_{i}")
            if completed:
                st.success(f"✅ Phase {i} completed!")

    with progress_col2:
        st.subheader("Weekly Goals")
        week_goal = st.number_input("Hours to study this week:", min_value=1, max_value=50, value=10)
        if st.button("Set Weekly Goal"):
            st.success(f"🎯 Weekly goal set: {week_goal} hours")
            st.balloons()

    # Download roadmap
    st.markdown("---")
    if st.button("📥 Download Roadmap as Text", type="secondary"):
        roadmap_text = generate_downloadable_roadmap(roadmap, subject, experience_level, learning_intensity)
        st.download_button(
            label="📄 Download Roadmap",
            data=roadmap_text,
            file_name=f"{subject}_roadmap_{datetime.date.today()}.txt",
            mime="text/plain"
        )

def get_timeline_multiplier(experience_level, learning_intensity):
    """Calculate timeline multiplier based on experience and intensity"""
    experience_multipliers = {
        "Complete Beginner": 1.3,
        "Some Experience": 1.1, 
        "Intermediate": 0.9,
        "Advanced": 0.7
    }

    intensity_multipliers = {
        "5-10 hours/week (Part-time)": 1.4,
        "10-20 hours/week (Regular)": 1.0,
        "20+ hours/week (Intensive)": 0.7
    }

    return experience_multipliers[experience_level] * intensity_multipliers[learning_intensity]

def adjust_timeline(original_time, multiplier):
    """Adjust the timeline based on multiplier"""
    if "3-6 months" in original_time:
        if multiplier > 1.2:
            return "4-8 months"
        elif multiplier < 0.8:
            return "2-4 months"
        else:
            return original_time
    elif "4-8 months" in original_time:
        if multiplier > 1.2:
            return "6-12 months"
        elif multiplier < 0.8:
            return "3-6 months"
        else:
            return original_time
    elif "5-8 months" in original_time:
        if multiplier > 1.2:
            return "7-12 months"
        elif multiplier < 0.8:
            return "4-6 months"
        else:
            return original_time
    elif "6-12 months" in original_time:
        if multiplier > 1.2:
            return "8-16 months"
        elif multiplier < 0.8:
            return "4-8 months"
        else:
            return original_time
    else:
        return original_time

def adjust_phase_duration(duration, multiplier):
    """Adjust phase duration based on multiplier"""
    if multiplier > 1.2:
        return duration.replace("weeks", "weeks (extended)")
    elif multiplier < 0.8:
        return duration.replace("weeks", "weeks (accelerated)")
    else:
        return duration

def get_personalized_tips(experience_level, phase_name):
    """Get personalized tips based on experience level and phase"""
    tips_db = {
        "Complete Beginner": {
            "Phase 1": "Take your time with fundamentals. Don't rush - solid foundations are crucial.",
            "Phase 2": "Practice coding daily, even if it's just 30 minutes. Consistency beats intensity.",
            "Phase 3": "Start building small projects to apply what you've learned.",
            "Phase 4": "Join coding communities for support and motivation.",
            "Phase 5": "Focus on building a portfolio to showcase your skills."
        },
        "Some Experience": {
            "Phase 1": "You can move through basics faster, but don't skip important concepts.",
            "Phase 2": "Focus on areas where you feel less confident.",
            "Phase 3": "Try to build more complex projects than basic tutorials.",
            "Phase 4": "Consider contributing to open-source projects.",
            "Phase 5": "Network with other developers and consider mentoring beginners."
        },
        "Intermediate": {
            "Phase 1": "Review fundamentals quickly and identify knowledge gaps.",
            "Phase 2": "Focus on advanced concepts and best practices.",
            "Phase 3": "Build projects that challenge your current skill level.",
            "Phase 4": "Explore cutting-edge technologies in your field.",
            "Phase 5": "Consider specializing in a particular area or leadership roles."
        },
        "Advanced": {
            "Phase 1": "Use this as a refresher and focus on areas for improvement.",
            "Phase 2": "Look for advanced and emerging topics not covered in basic curricula.",
            "Phase 3": "Build complex, production-ready applications.",
            "Phase 4": "Consider contributing to open-source or creating your own tools.",
            "Phase 5": "Focus on mentoring others and thought leadership."
        }
    }

    return tips_db.get(experience_level, {}).get(phase_name.split(":")[0].strip(), "")

def get_goal_specific_resources(subject, goals):
    """Get resources specific to user goals"""
    goal_resources = {
        "Get a job in tech": [
            "Job interview preparation platforms",
            "Technical interview practice sites",
            "Resume building resources",
            "Networking events and meetups"
        ],
        "Improve current skills": [
            "Advanced tutorials and courses",
            "Industry best practices guides",
            "Code review communities",
            "Professional development resources"
        ],
        "Build personal projects": [
            "Project idea repositories",
            "GitHub and portfolio guides",
            "Design inspiration sites",
            "Deployment platforms"
        ],
        "Prepare for interviews": [
            "Technical interview questions",
            "System design resources",
            "Coding challenge platforms",
            "Mock interview services"
        ],
        "Career transition": [
            "Career change success stories",
            "Bootcamp and certification programs",
            "Mentorship programs",
            "Industry transition guides"
        ],
        "Academic purposes": [
            "Academic papers and research",
            "University course materials",
            "Academic conferences and journals",
            "Research methodologies"
        ]
    }

    resources = []
    for goal in goals:
        if goal in goal_resources:
            resources.extend(goal_resources[goal])

    return list(set(resources))

def generate_downloadable_roadmap(roadmap, subject, experience_level, learning_intensity):
    """Generate a downloadable text version of the roadmap"""
    text = f"""{roadmap['title']}
{'='*len(roadmap['title'])}

Generated on: {datetime.date.today()}
Experience Level: {experience_level}
Learning Intensity: {learning_intensity}

DESCRIPTION:
{roadmap['description']}

ESTIMATED TIME: {roadmap['estimated_time']}
DIFFICULTY: {roadmap['difficulty']}

LEARNING PHASES:
"""

    for i, phase in enumerate(roadmap['phases'], 1):
        text += f"""
Phase {i}: {phase['phase']}
Duration: {phase['duration']}

Topics:
"""
        for topic in phase['topics']:
            text += f"  • {topic}\n"

    text += f"""

RECOMMENDED RESOURCES:
"""
    for resource in roadmap['resources']:
        text += f"  • {resource}\n"

    text += """

---
Generated by Learning Roadmap Generator
Happy Learning! 🚀
"""

    return text

# About section in sidebar
st.sidebar.markdown("---")
st.sidebar.markdown("### 📋 About")
st.sidebar.info("""
This tool generates personalized learning roadmaps for various tech subjects. 
Select your preferences and get a customized learning path with timeline estimates, 
resources, and progress tracking.
""")

st.sidebar.markdown("### 🔗 Available Subjects")
st.sidebar.markdown("""
- **DSA**: Data Structures & Algorithms
- **Frontend**: Web Frontend Development  
- **Backend**: Server-side Development
- **Python**: Python Programming
- **Machine Learning**: ML & AI
- **Mobile App**: iOS & Android Development
""")

if __name__ == "__main__":
    main()
