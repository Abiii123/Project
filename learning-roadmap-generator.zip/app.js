// Learning Roadmap Generator App
class RoadmapGenerator {
    constructor() {
        this.roadmapsData = {
            "DSA": {
                "title": "Data Structures and Algorithms Roadmap",
                "description": "Master DSA fundamentals to advanced topics",
                "estimated_time": "3-6 months",
                "difficulty": "Intermediate to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Foundations",
                        "duration": "2-3 weeks",
                        "topics": [
                            "Choose Programming Language (Python/Java/C++)",
                            "Basic Programming Syntax",
                            "Time and Space Complexity (Big-O notation)",
                            "Basic Math for DSA"
                        ]
                    },
                    {
                        "phase": "Phase 2: Basic Data Structures",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Arrays and Strings",
                            "Linked Lists",
                            "Stacks and Queues",
                            "Hash Tables/Maps"
                        ]
                    },
                    {
                        "phase": "Phase 3: Trees and Graphs",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Binary Trees",
                            "Binary Search Trees",
                            "Heaps",
                            "Graph Representations",
                            "BFS and DFS"
                        ]
                    },
                    {
                        "phase": "Phase 4: Advanced Algorithms",
                        "duration": "6-8 weeks",
                        "topics": [
                            "Dynamic Programming",
                            "Greedy Algorithms",
                            "Backtracking",
                            "Advanced Graph Algorithms"
                        ]
                    },
                    {
                        "phase": "Phase 5: Practice and Interview Prep",
                        "duration": "4-6 weeks",
                        "topics": [
                            "LeetCode Problems (Easy to Hard)",
                            "System Design Basics",
                            "Mock Interviews",
                            "Company-specific Problems"
                        ]
                    }
                ],
                "resources": [
                    "LeetCode",
                    "GeeksforGeeks",
                    "HackerRank",
                    "Codeforces",
                    "YouTube Channels (Abdul Bari, MIT OpenCourseWare)"
                ]
            },
            "Frontend": {
                "title": "Frontend Development Roadmap",
                "description": "Become a modern frontend developer",
                "estimated_time": "4-8 months",
                "difficulty": "Beginner to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Web Fundamentals",
                        "duration": "3-4 weeks",
                        "topics": [
                            "HTML5 (Semantic tags, Forms, Accessibility)",
                            "CSS3 (Grid, Flexbox, Animations)",
                            "JavaScript Fundamentals (ES6+)",
                            "DOM Manipulation"
                        ]
                    },
                    {
                        "phase": "Phase 2: Intermediate Skills",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Responsive Design",
                            "CSS Preprocessors (Sass/LESS)",
                            "Version Control (Git/GitHub)",
                            "Package Managers (npm/yarn)"
                        ]
                    },
                    {
                        "phase": "Phase 3: Frameworks and Libraries",
                        "duration": "6-8 weeks",
                        "topics": [
                            "React.js/Vue.js/Angular",
                            "State Management (Redux/Vuex)",
                            "Component-based Architecture",
                            "Routing"
                        ]
                    },
                    {
                        "phase": "Phase 4: Modern Tools",
                        "duration": "4-6 weeks",
                        "topics": [
                            "TypeScript",
                            "Build Tools (Webpack/Vite)",
                            "CSS Frameworks (Tailwind/Bootstrap)",
                            "Testing (Jest/Cypress)"
                        ]
                    },
                    {
                        "phase": "Phase 5: Advanced Topics",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Performance Optimization",
                            "Progressive Web Apps (PWA)",
                            "SEO and Accessibility",
                            "Deployment (Netlify/Vercel)"
                        ]
                    }
                ],
                "resources": [
                    "MDN Web Docs",
                    "FreeCodeCamp",
                    "The Odin Project",
                    "React Documentation",
                    "YouTube (Traversy Media, Net Ninja)"
                ]
            },
            "Backend": {
                "title": "Backend Development Roadmap",
                "description": "Master server-side development",
                "estimated_time": "5-8 months",
                "difficulty": "Intermediate to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Programming Language",
                        "duration": "3-4 weeks",
                        "topics": [
                            "Choose Language (Python/Node.js/Java)",
                            "Language Fundamentals",
                            "Object-Oriented Programming",
                            "Error Handling"
                        ]
                    },
                    {
                        "phase": "Phase 2: Web Fundamentals",
                        "duration": "3-4 weeks",
                        "topics": [
                            "HTTP/HTTPS Protocols",
                            "REST API Design",
                            "JSON and Data Formats",
                            "Authentication & Authorization"
                        ]
                    },
                    {
                        "phase": "Phase 3: Databases",
                        "duration": "4-6 weeks",
                        "topics": [
                            "SQL Databases (PostgreSQL/MySQL)",
                            "NoSQL Databases (MongoDB)",
                            "Database Design",
                            "ORMs and Query Builders"
                        ]
                    },
                    {
                        "phase": "Phase 4: Framework and APIs",
                        "duration": "6-8 weeks",
                        "topics": [
                            "Web Frameworks (Django/Express/Spring)",
                            "API Development",
                            "Database Integration",
                            "Middleware and Security"
                        ]
                    },
                    {
                        "phase": "Phase 5: DevOps and Deployment",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Docker and Containerization",
                            "Cloud Platforms (AWS/GCP/Azure)",
                            "CI/CD Pipelines",
                            "Monitoring and Logging"
                        ]
                    }
                ],
                "resources": [
                    "Django Documentation",
                    "Express.js Documentation",
                    "PostgreSQL Tutorial",
                    "Docker Documentation",
                    "YouTube (Programming with Mosh, Tech with Tim)"
                ]
            },
            "Python": {
                "title": "Python Programming Roadmap",
                "description": "From beginner to Python expert",
                "estimated_time": "4-6 months",
                "difficulty": "Beginner to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Python Basics",
                        "duration": "2-3 weeks",
                        "topics": [
                            "Installation and Setup",
                            "Basic Syntax and Variables",
                            "Data Types and Operations",
                            "Control Structures (if/else, loops)"
                        ]
                    },
                    {
                        "phase": "Phase 2: Intermediate Python",
                        "duration": "3-4 weeks",
                        "topics": [
                            "Functions and Modules",
                            "Object-Oriented Programming",
                            "File Handling",
                            "Error Handling and Debugging"
                        ]
                    },
                    {
                        "phase": "Phase 3: Python Libraries",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Standard Library",
                            "NumPy and Pandas",
                            "Matplotlib for Visualization",
                            "Web Scraping (BeautifulSoup)"
                        ]
                    },
                    {
                        "phase": "Phase 4: Specialization",
                        "duration": "6-8 weeks",
                        "topics": [
                            "Web Development (Django/Flask)",
                            "Data Analysis/Machine Learning",
                            "Automation and Scripting",
                            "APIs and Databases"
                        ]
                    },
                    {
                        "phase": "Phase 5: Advanced Python",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Decorators and Generators",
                            "Async Programming",
                            "Testing (unittest/pytest)",
                            "Package Distribution"
                        ]
                    }
                ],
                "resources": [
                    "Python.org Documentation",
                    "Real Python",
                    "Codecademy Python Course",
                    "Python Crash Course Book",
                    "YouTube (Corey Schafer, Tech with Tim)"
                ]
            },
            "Machine Learning": {
                "title": "Machine Learning Roadmap",
                "description": "Master ML from fundamentals to advanced",
                "estimated_time": "6-12 months",
                "difficulty": "Intermediate to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Mathematical Foundations",
                        "duration": "4-6 weeks",
                        "topics": [
                            "Linear Algebra",
                            "Statistics and Probability",
                            "Calculus Basics",
                            "Python for Data Science"
                        ]
                    },
                    {
                        "phase": "Phase 2: Data Handling",
                        "duration": "3-4 weeks",
                        "topics": [
                            "NumPy and Pandas",
                            "Data Cleaning and Preprocessing",
                            "Exploratory Data Analysis",
                            "Data Visualization (Matplotlib/Seaborn)"
                        ]
                    },
                    {
                        "phase": "Phase 3: Machine Learning Basics",
                        "duration": "6-8 weeks",
                        "topics": [
                            "Supervised Learning (Regression/Classification)",
                            "Unsupervised Learning (Clustering)",
                            "Model Evaluation and Validation",
                            "Scikit-learn"
                        ]
                    },
                    {
                        "phase": "Phase 4: Advanced ML",
                        "duration": "8-10 weeks",
                        "topics": [
                            "Feature Engineering",
                            "Ensemble Methods",
                            "Deep Learning Basics",
                            "Neural Networks (TensorFlow/PyTorch)"
                        ]
                    },
                    {
                        "phase": "Phase 5: Specialized Areas",
                        "duration": "8-12 weeks",
                        "topics": [
                            "Computer Vision",
                            "Natural Language Processing",
                            "Time Series Analysis",
                            "MLOps and Deployment"
                        ]
                    }
                ],
                "resources": [
                    "Coursera ML Course (Andrew Ng)",
                    "Kaggle Learn",
                    "Fast.ai",
                    "TensorFlow Documentation",
                    "YouTube (3Blue1Brown, StatQuest)"
                ]
            },
            "Mobile App Development": {
                "title": "Mobile App Development Roadmap",
                "description": "Build apps for iOS and Android",
                "estimated_time": "6-10 months",
                "difficulty": "Intermediate to Advanced",
                "phases": [
                    {
                        "phase": "Phase 1: Fundamentals",
                        "duration": "2-3 weeks",
                        "topics": [
                            "Mobile Development Concepts",
                            "UI/UX Design Principles",
                            "Choose Platform (Native/Cross-platform)",
                            "Development Environment Setup"
                        ]
                    },
                    {
                        "phase": "Phase 2: Platform Specific",
                        "duration": "6-8 weeks",
                        "topics": [
                            "iOS: Swift/SwiftUI or Android: Kotlin",
                            "Platform-specific IDEs (Xcode/Android Studio)",
                            "Native UI Components",
                            "Platform Guidelines"
                        ]
                    },
                    {
                        "phase": "Phase 3: Cross-Platform (Optional)",
                        "duration": "6-8 weeks",
                        "topics": [
                            "React Native or Flutter",
                            "Shared Business Logic",
                            "Platform-specific Adaptations",
                            "Performance Optimization"
                        ]
                    },
                    {
                        "phase": "Phase 4: Advanced Features",
                        "duration": "6-8 weeks",
                        "topics": [
                            "Data Persistence (SQLite/Core Data)",
                            "Networking and APIs",
                            "Push Notifications",
                            "Authentication and Security"
                        ]
                    },
                    {
                        "phase": "Phase 5: Publishing and Maintenance",
                        "duration": "3-4 weeks",
                        "topics": [
                            "App Store Guidelines",
                            "Beta Testing (TestFlight/Play Console)",
                            "App Store Optimization (ASO)",
                            "Analytics and Crash Reporting"
                        ]
                    }
                ],
                "resources": [
                    "Apple Developer Documentation",
                    "Android Developer Documentation",
                    "React Native Documentation",
                    "Flutter Documentation",
                    "YouTube (CodeWithChris, Philipp Lackner)"
                ]
            }
        };

        this.currentRoadmap = null;
        this.completedPhases = new Set();
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        const form = document.getElementById('roadmapForm');
        const resetBtn = document.getElementById('resetBtn');
        const downloadBtn = document.getElementById('downloadBtn');

        if (form) {
            form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        }
        if (resetBtn) {
            resetBtn.addEventListener('click', () => this.resetApp());
        }
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => this.downloadRoadmap());
        }
    }

    async handleFormSubmit(e) {
        e.preventDefault();
        
        const formData = this.getFormData();
        if (!this.validateForm(formData)) return;

        this.showLoading();
        
        // Simulate processing time
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        this.generateRoadmap(formData);
        this.hideLoading();
        this.showRoadmap();
    }

    getFormData() {
        const subjectEl = document.getElementById('subject');
        const experienceEl = document.getElementById('experience');
        const intensityEl = document.getElementById('intensity');
        const goalCheckboxes = document.querySelectorAll('.goal-checkbox:checked');

        const subject = subjectEl ? subjectEl.value : '';
        const experience = experienceEl ? experienceEl.value : '';
        const intensity = intensityEl ? intensityEl.value : '';
        const goals = Array.from(goalCheckboxes).map(cb => cb.value);

        return { subject, experience, intensity, goals };
    }

    validateForm(formData) {
        if (!formData.subject) {
            alert('Please select a subject to learn');
            return false;
        }
        if (!formData.experience) {
            alert('Please select your experience level');
            return false;
        }
        if (!formData.intensity) {
            alert('Please select your learning intensity');
            return false;
        }
        if (formData.goals.length === 0) {
            alert('Please select at least one learning goal');
            return false;
        }
        return true;
    }

    generateRoadmap(formData) {
        const baseRoadmap = this.roadmapsData[formData.subject];
        if (!baseRoadmap) {
            alert('Roadmap data not found for selected subject');
            return;
        }
        
        this.currentRoadmap = this.personalizeRoadmap(baseRoadmap, formData);
        this.renderRoadmap();
    }

    personalizeRoadmap(roadmap, formData) {
        const personalized = JSON.parse(JSON.stringify(roadmap));
        
        // Adjust timeline based on experience and intensity
        personalized.estimated_time = this.adjustTimeline(roadmap.estimated_time, formData.experience, formData.intensity);
        
        // Add personalized tips for each phase
        personalized.phases = personalized.phases.map((phase, index) => ({
            ...phase,
            tips: this.generatePersonalizedTips(formData, index, roadmap.title)
        }));

        // Add goal-specific resources
        personalized.goalResources = this.getGoalSpecificResources(formData.goals, formData.subject);

        return personalized;
    }

    adjustTimeline(originalTime, experience, intensity) {
        const timeRanges = originalTime.match(/(\d+)-(\d+)/);
        if (!timeRanges) return originalTime;

        let minTime = parseInt(timeRanges[1]);
        let maxTime = parseInt(timeRanges[2]);

        // Adjust based on experience
        const experienceMultipliers = {
            'beginner': 1.3,
            'some': 1.1,
            'intermediate': 0.9,
            'advanced': 0.7
        };

        // Adjust based on intensity
        const intensityMultipliers = {
            'part-time': 1.4,
            'regular': 1.0,
            'intensive': 0.7
        };

        const expMultiplier = experienceMultipliers[experience] || 1;
        const intMultiplier = intensityMultipliers[intensity] || 1;
        
        minTime = Math.ceil(minTime * expMultiplier * intMultiplier);
        maxTime = Math.ceil(maxTime * expMultiplier * intMultiplier);

        const unit = originalTime.includes('month') ? 'months' : 'weeks';
        return `${minTime}-${maxTime} ${unit}`;
    }

    generatePersonalizedTips(formData, phaseIndex, roadmapTitle) {
        const tipDatabase = {
            beginner: [
                "Take your time with fundamentals - they're crucial for everything that follows.",
                "Don't rush through concepts. Practice extensively before moving on.",
                "Join beginner-friendly communities for support and questions.",
                "Focus on understanding rather than just completing topics.",
                "Build small projects to reinforce your learning."
            ],
            some: [
                "Review fundamentals if you feel uncertain about any topic.",
                "Try to connect new concepts with what you already know.",
                "Consider pair programming or study groups for better learning.",
                "Start building slightly more complex projects.",
                "Don't skip the practice problems - they're essential."
            ],
            intermediate: [
                "Challenge yourself with more complex problems and projects.",
                "Focus on best practices and code quality.",
                "Consider contributing to open-source projects.",
                "Start thinking about system design and architecture.",
                "Mentor beginners to reinforce your own knowledge."
            ],
            advanced: [
                "Focus on advanced topics and cutting-edge technologies.",
                "Consider specializing in specific areas of interest.",
                "Share your knowledge through blog posts or talks.",
                "Work on large-scale, complex projects.",
                "Stay updated with industry trends and research."
            ]
        };

        const tips = tipDatabase[formData.experience] || tipDatabase.some;
        return tips[phaseIndex % tips.length];
    }

    getGoalSpecificResources(goals, subject) {
        const goalResourceMap = {
            job: [
                "Indeed Job Search",
                "LinkedIn Job Listings",
                "AngelList (for startups)",
                "Company Career Pages",
                "Technical Interview Prep Books"
            ],
            improve: [
                "Advanced Courses on Coursera/Udemy",
                "Industry Blogs and Publications",
                "Professional Conferences",
                "Advanced Certification Programs"
            ],
            projects: [
                "GitHub for Code Hosting",
                "Project Idea Generators",
                "Open Source Contribution Guides",
                "Personal Portfolio Templates"
            ],
            interviews: [
                "LeetCode Premium",
                "InterviewBit",
                "Pramp for Mock Interviews",
                "Cracking the Coding Interview Book",
                "System Design Interview Books"
            ],
            transition: [
                "Career Change Success Stories",
                "Networking Events and Meetups",
                "Career Counseling Services",
                "Industry Mentorship Programs"
            ],
            academic: [
                "University Course Materials",
                "Research Papers and Journals",
                "Academic Conference Proceedings",
                "Textbooks and Reference Materials"
            ]
        };

        const resources = [];
        goals.forEach(goal => {
            if (goalResourceMap[goal]) {
                resources.push(...goalResourceMap[goal]);
            }
        });

        return [...new Set(resources)]; // Remove duplicates
    }

    renderRoadmap() {
        // Update header
        const titleEl = document.getElementById('roadmapTitle');
        const descEl = document.getElementById('roadmapDescription');
        const timeEl = document.getElementById('roadmapTime');
        const diffEl = document.getElementById('roadmapDifficulty');

        if (titleEl) titleEl.textContent = this.currentRoadmap.title;
        if (descEl) descEl.textContent = this.currentRoadmap.description;
        if (timeEl) timeEl.textContent = this.currentRoadmap.estimated_time;
        if (diffEl) diffEl.textContent = this.currentRoadmap.difficulty;

        // Update progress
        const totalEl = document.getElementById('totalPhases');
        if (totalEl) totalEl.textContent = this.currentRoadmap.phases.length;
        this.updateProgress();

        // Render phases
        this.renderPhases();

        // Render resources
        this.renderResources();
    }

    renderPhases() {
        const container = document.getElementById('phasesContainer');
        if (!container) return;
        
        container.innerHTML = '';

        this.currentRoadmap.phases.forEach((phase, index) => {
            const phaseCard = this.createPhaseCard(phase, index + 1);
            container.appendChild(phaseCard);
        });
    }

    createPhaseCard(phase, phaseNumber) {
        const card = document.createElement('div');
        card.className = 'phase-card';
        card.dataset.phase = phaseNumber;

        card.innerHTML = `
            <div class="phase-header">
                <div class="phase-info">
                    <div style="display: flex; align-items: center;">
                        <span class="phase-number">${phaseNumber}</span>
                        <div>
                            <h3 class="phase-title">${phase.phase}</h3>
                            <p class="phase-duration">${phase.duration}</p>
                        </div>
                    </div>
                </div>
                <div class="phase-controls">
                    <input type="checkbox" class="complete-checkbox" />
                    <button class="toggle-btn" type="button">▼</button>
                </div>
            </div>
            <div class="phase-content" id="phase-content-${phaseNumber}">
                <ul class="topics-list">
                    ${phase.topics.map(topic => `<li>${topic}</li>`).join('')}
                </ul>
                <div class="phase-tips">
                    <h4>💡 Personalized Tip</h4>
                    <p>${phase.tips}</p>
                </div>
            </div>
        `;

        // Add event listeners
        const header = card.querySelector('.phase-header');
        const toggleBtn = card.querySelector('.toggle-btn');
        const checkbox = card.querySelector('.complete-checkbox');

        header.addEventListener('click', (e) => {
            if (e.target === checkbox) return; // Don't toggle when clicking checkbox
            this.togglePhase(phaseNumber);
        });

        checkbox.addEventListener('change', (e) => {
            e.stopPropagation();
            this.togglePhaseCompletion(phaseNumber);
        });

        return card;
    }

    togglePhase(phaseNumber) {
        const content = document.getElementById(`phase-content-${phaseNumber}`);
        const toggleBtn = document.querySelector(`[data-phase="${phaseNumber}"] .toggle-btn`);
        
        if (content && toggleBtn) {
            content.classList.toggle('expanded');
            toggleBtn.classList.toggle('expanded');
        }
    }

    togglePhaseCompletion(phaseNumber) {
        const checkbox = document.querySelector(`[data-phase="${phaseNumber}"] .complete-checkbox`);
        const card = document.querySelector(`[data-phase="${phaseNumber}"]`);
        
        if (!checkbox || !card) return;

        if (checkbox.checked) {
            this.completedPhases.add(phaseNumber);
            card.classList.add('completed');
        } else {
            this.completedPhases.delete(phaseNumber);
            card.classList.remove('completed');
        }
        
        this.updateProgress();
    }

    renderResources() {
        // General resources
        const generalList = document.getElementById('generalResources');
        if (generalList && this.currentRoadmap.resources) {
            generalList.innerHTML = this.currentRoadmap.resources
                .map(resource => `<li>${resource}</li>`)
                .join('');
        }

        // Goal-specific resources
        const goalList = document.getElementById('goalResources');
        if (goalList && this.currentRoadmap.goalResources) {
            goalList.innerHTML = this.currentRoadmap.goalResources
                .map(resource => `<li>${resource}</li>`)
                .join('');
        }
    }

    updateProgress() {
        const completed = this.completedPhases.size;
        const total = this.currentRoadmap ? this.currentRoadmap.phases.length : 0;
        const percentage = total > 0 ? (completed / total) * 100 : 0;

        const progressCount = document.getElementById('progressCount');
        const progressFill = document.getElementById('progressFill');

        if (progressCount) progressCount.textContent = completed;
        if (progressFill) progressFill.style.width = `${percentage}%`;
    }

    showLoading() {
        const formContainer = document.getElementById('formContainer');
        const loadingState = document.getElementById('loadingState');
        
        if (formContainer) formContainer.classList.add('hidden');
        if (loadingState) loadingState.classList.remove('hidden');
    }

    hideLoading() {
        const loadingState = document.getElementById('loadingState');
        if (loadingState) loadingState.classList.add('hidden');
    }

    showRoadmap() {
        const roadmapContainer = document.getElementById('roadmapContainer');
        if (roadmapContainer) roadmapContainer.classList.remove('hidden');
    }

    resetApp() {
        this.completedPhases.clear();
        this.currentRoadmap = null;
        
        const roadmapContainer = document.getElementById('roadmapContainer');
        const formContainer = document.getElementById('formContainer');
        const form = document.getElementById('roadmapForm');
        
        if (roadmapContainer) roadmapContainer.classList.add('hidden');
        if (formContainer) formContainer.classList.remove('hidden');
        if (form) form.reset();
    }

    downloadRoadmap() {
        if (!this.currentRoadmap) return;

        const content = this.generateDownloadContent();
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `${this.currentRoadmap.title.replace(/\s+/g, '_')}_Roadmap.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    generateDownloadContent() {
        let content = `${this.currentRoadmap.title}\n`;
        content += `${'='.repeat(this.currentRoadmap.title.length)}\n\n`;
        content += `${this.currentRoadmap.description}\n\n`;
        content += `Estimated Time: ${this.currentRoadmap.estimated_time}\n`;
        content += `Difficulty: ${this.currentRoadmap.difficulty}\n\n`;

        // Phases
        content += 'LEARNING PHASES:\n';
        content += '================\n\n';
        
        this.currentRoadmap.phases.forEach((phase, index) => {
            content += `${phase.phase}\n`;
            content += `Duration: ${phase.duration}\n`;
            content += 'Topics:\n';
            phase.topics.forEach(topic => {
                content += `  • ${topic}\n`;
            });
            content += `\nTip: ${phase.tips}\n\n`;
        });

        // Resources
        content += 'RESOURCES:\n';
        content += '==========\n\n';
        content += 'General Resources:\n';
        this.currentRoadmap.resources.forEach(resource => {
            content += `• ${resource}\n`;
        });

        content += '\nGoal-Specific Resources:\n';
        this.currentRoadmap.goalResources.forEach(resource => {
            content += `• ${resource}\n`;
        });

        return content;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.app = new RoadmapGenerator();
});