from flask import Flask, render_template, request, jsonify, send_from_directory
import json
import datetime
import os

app = Flask(__name__)

# Load roadmaps data
def load_roadmaps_data():
    try:
        with open('roadmaps_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

@app.route('/')
def index():
    """Main page with roadmap generator form"""
    roadmaps_data = load_roadmaps_data()
    subjects = list(roadmaps_data.keys())
    return render_template('index.html', subjects=subjects)

@app.route('/generate_roadmap', methods=['POST'])
def generate_roadmap():
    """Generate personalized roadmap based on user input"""
    data = request.get_json()

    subject = data.get('subject')
    experience_level = data.get('experience_level')
    learning_intensity = data.get('learning_intensity')
    goals = data.get('goals', [])

    roadmaps_data = load_roadmaps_data()

    if subject not in roadmaps_data:
        return jsonify({'error': 'Subject not found'}), 400

    roadmap = roadmaps_data[subject]

    # Calculate timeline adjustments
    timeline_multiplier = get_timeline_multiplier(experience_level, learning_intensity)
    adjusted_time = adjust_timeline(roadmap['estimated_time'], timeline_multiplier)

    # Prepare response
    response = {
        'title': roadmap['title'],
        'description': roadmap['description'],
        'estimated_time': adjusted_time,
        'difficulty': roadmap['difficulty'],
        'phases': [],
        'resources': roadmap['resources'],
        'goal_specific_resources': get_goal_specific_resources(subject, goals)
    }

    # Process phases with personalized tips
    for i, phase in enumerate(roadmap['phases'], 1):
        adjusted_duration = adjust_phase_duration(phase['duration'], timeline_multiplier)
        tips = get_personalized_tips(experience_level, phase['phase'])

        response['phases'].append({
            'number': i,
            'title': phase['phase'],
            'duration': adjusted_duration,
            'topics': phase['topics'],
            'tips': tips
        })

    return jsonify(response)

def get_timeline_multiplier(experience_level, learning_intensity):
    """Calculate timeline multiplier"""
    experience_multipliers = {
        "Complete Beginner": 1.3,
        "Some Experience": 1.1, 
        "Intermediate": 0.9,
        "Advanced": 0.7
    }

    intensity_multipliers = {
        "5-10 hours/week": 1.4,
        "10-20 hours/week": 1.0,
        "20+ hours/week": 0.7
    }

    return experience_multipliers.get(experience_level, 1.0) * intensity_multipliers.get(learning_intensity, 1.0)

def adjust_timeline(original_time, multiplier):
    """Adjust timeline based on multiplier"""
    adjustments = {
        "3-6 months": {"high": "4-8 months", "low": "2-4 months"},
        "4-8 months": {"high": "6-12 months", "low": "3-6 months"},
        "5-8 months": {"high": "7-12 months", "low": "4-6 months"},
        "6-12 months": {"high": "8-16 months", "low": "4-8 months"}
    }

    if original_time in adjustments:
        if multiplier > 1.2:
            return adjustments[original_time]["high"]
        elif multiplier < 0.8:
            return adjustments[original_time]["low"]

    return original_time

def adjust_phase_duration(duration, multiplier):
    """Adjust phase duration"""
    if multiplier > 1.2:
        return duration.replace("weeks", "weeks (extended)")
    elif multiplier < 0.8:
        return duration.replace("weeks", "weeks (accelerated)")
    return duration

def get_personalized_tips(experience_level, phase_name):
    """Get personalized tips"""
    tips_db = {
        "Complete Beginner": {
            "Phase 1": "Take your time with fundamentals. Solid foundations are crucial.",
            "Phase 2": "Practice daily, even if just 30 minutes. Consistency beats intensity.",
            "Phase 3": "Start building small projects to apply what you've learned.",
            "Phase 4": "Join coding communities for support and motivation.",
            "Phase 5": "Focus on building a portfolio to showcase your skills."
        },
        "Some Experience": {
            "Phase 1": "Move through basics faster, but don't skip important concepts.",
            "Phase 2": "Focus on areas where you feel less confident.",
            "Phase 3": "Build more complex projects than basic tutorials.",
            "Phase 4": "Consider contributing to open-source projects.",
            "Phase 5": "Network with other developers and consider mentoring."
        },
        "Intermediate": {
            "Phase 1": "Review fundamentals quickly and identify knowledge gaps.",
            "Phase 2": "Focus on advanced concepts and best practices.", 
            "Phase 3": "Build projects that challenge your current skill level.",
            "Phase 4": "Explore cutting-edge technologies in your field.",
            "Phase 5": "Consider specializing or taking leadership roles."
        },
        "Advanced": {
            "Phase 1": "Use as refresher and focus on improvement areas.",
            "Phase 2": "Look for advanced topics not in basic curricula.",
            "Phase 3": "Build complex, production-ready applications.",
            "Phase 4": "Consider contributing to open-source or creating tools.",
            "Phase 5": "Focus on mentoring others and thought leadership."
        }
    }

    return tips_db.get(experience_level, {}).get(phase_name.split(":")[0].strip(), "")

def get_goal_specific_resources(subject, goals):
    """Get goal-specific resources"""
    goal_resources = {
        "Get a job in tech": [
            "Job interview preparation platforms",
            "Technical interview practice sites", 
            "Resume building resources",
            "Networking events and meetups"
        ],
        "Improve current skills": [
            "Advanced tutorials and courses",
            "Industry best practices guides",
            "Code review communities", 
            "Professional development resources"
        ],
        "Build personal projects": [
            "Project idea repositories",
            "GitHub and portfolio guides",
            "Design inspiration sites",
            "Deployment platforms"
        ],
        "Prepare for interviews": [
            "Technical interview questions",
            "System design resources",
            "Coding challenge platforms",
            "Mock interview services"
        ],
        "Career transition": [
            "Career change success stories",
            "Bootcamp and certification programs",
            "Mentorship programs",
            "Industry transition guides"
        ],
        "Academic purposes": [
            "Academic papers and research",
            "University course materials",
            "Academic conferences and journals",
            "Research methodologies"
        ]
    }

    resources = []
    for goal in goals:
        if goal in goal_resources:
            resources.extend(goal_resources[goal])

    return list(set(resources))

if __name__ == '__main__':
    app.run(debug=True)
