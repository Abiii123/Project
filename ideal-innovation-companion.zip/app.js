// Ideal - AI-Powered Innovation Companion JavaScript

class IdealApp {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 5;
        this.formData = {};
        this.sampleBlueprints = {
            "mobileApp": {
                "title": "Sustainable Restaurant Finder App",
                "executiveSummary": "A mobile application connecting eco-conscious diners with sustainable restaurants based on environmental impact ratings and dietary preferences.",
                "problemAnalysis": {
                    "coreProblem": "Difficulty finding restaurants that align with environmental values and dietary restrictions",
                    "targetAudience": "Environmentally conscious millennials and Gen Z consumers aged 25-40",
                    "marketOpportunity": "$50B sustainable dining market growing at 12% annually",
                    "challenges": ["Data collection complexity", "Restaurant onboarding", "User adoption"]
                },
                "technologyStack": {
                    "frontend": "React Native for cross-platform development",
                    "backend": "Node.js with Express.js and PostgreSQL",
                    "apis": "Google Maps API, Yelp API, custom sustainability database",
                    "infrastructure": "AWS with auto-scaling capabilities"
                },
                "features": [
                    "Location-based restaurant discovery",
                    "Sustainability rating system",
                    "Dietary preference filtering",
                    "User reviews and ratings",
                    "Reservation integration",
                    "Social sharing features"
                ],
                "roadmap": [
                    {
                        "phase": "MVP (Months 1-2)",
                        "features": ["Basic restaurant discovery", "Simple filtering", "User profiles"]
                    },
                    {
                        "phase": "Growth (Months 3-4)",
                        "features": ["Sustainability ratings", "Advanced filters", "Reviews system"]
                    },
                    {
                        "phase": "Scale (Months 5-6)",
                        "features": ["Social features", "Recommendations", "Restaurant partnerships"]
                    }
                ],
                "uiuxGuidelines": [
                    "Map-based primary interface",
                    "Green color scheme reflecting sustainability",
                    "Clear rating indicators",
                    "Intuitive filtering system",
                    "Seamless reservation flow"
                ],
                "knowledgeResources": [
                    "React Native Documentation",
                    "Google Maps API Guide",
                    "Sustainable Business Practices",
                    "Mobile UX Design Patterns",
                    "Restaurant Industry Reports"
                ],
                "deploymentStrategy": {
                    "development": "Local development with Docker containers",
                    "staging": "AWS staging environment with CI/CD pipeline",
                    "production": "Multi-region AWS deployment with auto-scaling",
                    "monitoring": "CloudWatch and custom analytics dashboard"
                }
            },
            "webService": {
                "title": "AI-Powered Project Management Tool",
                "executiveSummary": "An intelligent project management platform that uses AI to predict project risks, optimize resource allocation, and suggest timeline improvements.",
                "problemAnalysis": {
                    "coreProblem": "Traditional project management tools lack predictive capabilities and intelligent optimization",
                    "targetAudience": "Small to medium businesses, remote teams, project managers",
                    "marketOpportunity": "$6.68B project management software market",
                    "challenges": ["AI model accuracy", "Data integration", "User trust in AI recommendations"]
                },
                "technologyStack": {
                    "frontend": "Next.js with TypeScript and Tailwind CSS",
                    "backend": "Python FastAPI with PostgreSQL and Redis",
                    "ai": "OpenAI GPT-4, custom ML models for prediction",
                    "infrastructure": "Vercel frontend, AWS backend services"
                },
                "features": [
                    "Intelligent task scheduling",
                    "Risk prediction algorithms",
                    "Resource optimization",
                    "Team collaboration tools",
                    "Progress analytics",
                    "Integration with popular tools"
                ],
                "roadmap": [
                    {
                        "phase": "Foundation (Months 1-3)",
                        "features": ["Core project management", "Basic AI suggestions", "Team collaboration"]
                    },
                    {
                        "phase": "Intelligence (Months 4-6)",
                        "features": ["Advanced AI predictions", "Risk analysis", "Optimization algorithms"]
                    },
                    {
                        "phase": "Enterprise (Months 7-9)",
                        "features": ["Enterprise integrations", "Advanced analytics", "Custom AI models"]
                    }
                ],
                "uiuxGuidelines": [
                    "Dashboard-centric design",
                    "Data visualization focus",
                    "Clean, professional interface",
                    "AI insights prominently displayed",
                    "Mobile-responsive design"
                ],
                "knowledgeResources": [
                    "Project Management Best Practices",
                    "Machine Learning for Business",
                    "Next.js Documentation",
                    "FastAPI Guide",
                    "Enterprise Software Design"
                ],
                "deploymentStrategy": {
                    "development": "Local development with Docker Compose",
                    "staging": "Vercel preview deployments",
                    "production": "Vercel for frontend, AWS ECS for backend",
                    "monitoring": "DataDog for application monitoring"
                }
            }
        };
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateProgress();
    }

    bindEvents() {
        // Navigation
        document.getElementById('get-started-nav').addEventListener('click', () => this.showSection('idea-form-section'));
        document.getElementById('get-started-hero').addEventListener('click', () => this.showSection('idea-form-section'));
        document.getElementById('learn-more').addEventListener('click', () => this.scrollToSection('how-it-works'));

        // Form navigation
        document.getElementById('next-step').addEventListener('click', () => this.nextStep());
        document.getElementById('prev-step').addEventListener('click', () => this.prevStep());
        document.getElementById('submit-form').addEventListener('click', (e) => this.submitForm(e));

        // Results actions
        document.getElementById('download-pdf').addEventListener('click', () => this.downloadPDF());
        document.getElementById('share-blueprint').addEventListener('click', () => this.shareBlueprint());
        document.getElementById('create-another').addEventListener('click', () => this.createAnother());

        // Smooth scrolling for navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = link.getAttribute('href').substring(1);
                this.scrollToSection(target);
                this.setActiveNavLink(link);
            });
        });

        // Form validation
        this.addFormValidation();
    }

    showSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('section').forEach(section => {
            section.classList.add('hidden');
        });

        // Show target section
        document.getElementById(sectionId).classList.remove('hidden');
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Add fade-in animation
        document.getElementById(sectionId).classList.add('fade-in');
    }

    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    }

    setActiveNavLink(activeLink) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }

    nextStep() {
        if (this.validateCurrentStep()) {
            this.saveCurrentStepData();
            
            if (this.currentStep < this.totalSteps) {
                this.currentStep++;
                this.showStep(this.currentStep);
                this.updateProgress();
            }
        }
    }

    prevStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.showStep(this.currentStep);
            this.updateProgress();
        }
    }

    showStep(stepNumber) {
        // Hide all steps
        document.querySelectorAll('.form-step').forEach(step => {
            step.classList.remove('active');
        });

        // Show current step
        document.querySelector(`[data-step="${stepNumber}"]`).classList.add('active');

        // Update button visibility
        this.updateButtons();

        // Add slide animation
        document.querySelector(`[data-step="${stepNumber}"]`).classList.add('slide-up');
    }

    updateProgress() {
        const progress = (this.currentStep / this.totalSteps) * 100;
        document.getElementById('progress-fill').style.width = `${progress}%`;
        document.getElementById('current-step').textContent = this.currentStep;
        document.getElementById('total-steps').textContent = this.totalSteps;
    }

    updateButtons() {
        const prevBtn = document.getElementById('prev-step');
        const nextBtn = document.getElementById('next-step');
        const submitBtn = document.getElementById('submit-form');

        prevBtn.style.display = this.currentStep === 1 ? 'none' : 'inline-flex';
        
        if (this.currentStep === this.totalSteps) {
            nextBtn.classList.add('hidden');
            submitBtn.classList.remove('hidden');
        } else {
            nextBtn.classList.remove('hidden');
            submitBtn.classList.add('hidden');
        }
    }

    validateCurrentStep() {
        const currentStepElement = document.querySelector(`[data-step="${this.currentStep}"]`);
        const requiredFields = currentStepElement.querySelectorAll('[required]');
        
        let isValid = true;
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'This field is required');
                isValid = false;
            } else {
                this.clearFieldError(field);
            }
        });

        return isValid;
    }

    showFieldError(field, message) {
        this.clearFieldError(field);
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.color = 'var(--color-error)';
        errorDiv.style.fontSize = 'var(--font-size-sm)';
        errorDiv.style.marginTop = 'var(--space-4)';
        errorDiv.textContent = message;
        
        field.parentNode.appendChild(errorDiv);
        field.style.borderColor = 'var(--color-error)';
    }

    clearFieldError(field) {
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        field.style.borderColor = '';
    }

    saveCurrentStepData() {
        const currentStepElement = document.querySelector(`[data-step="${this.currentStep}"]`);
        const inputs = currentStepElement.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            this.formData[input.id] = input.value;
        });
    }

    addFormValidation() {
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                if (input.hasAttribute('required') && !input.value.trim()) {
                    this.showFieldError(input, 'This field is required');
                } else {
                    this.clearFieldError(input);
                }
            });
        });
    }

    submitForm(e) {
        e.preventDefault();
        
        if (this.validateCurrentStep()) {
            this.saveCurrentStepData();
            this.showProcessing();
        }
    }

    showProcessing() {
        this.showSection('processing-section');
        this.simulateProcessing();
    }

    simulateProcessing() {
        const steps = [
            { id: 'step-analyze', text: 'Analyzing your idea and market...', duration: 2000 },
            { id: 'step-technology', text: 'Selecting optimal technology stack...', duration: 2500 },
            { id: 'step-roadmap', text: 'Creating development roadmap...', duration: 2000 },
            { id: 'step-finalize', text: 'Finalizing your blueprint...', duration: 1500 }
        ];

        let currentStepIndex = 0;

        const processStep = () => {
            if (currentStepIndex > 0) {
                document.getElementById(steps[currentStepIndex - 1].id).classList.remove('active');
                document.getElementById(steps[currentStepIndex - 1].id).classList.add('completed');
            }

            if (currentStepIndex < steps.length) {
                const step = steps[currentStepIndex];
                document.getElementById(step.id).classList.add('active');
                document.getElementById('processing-text').textContent = step.text;

                setTimeout(() => {
                    currentStepIndex++;
                    processStep();
                }, step.duration);
            } else {
                // Processing complete
                setTimeout(() => {
                    this.generateBlueprint();
                }, 1000);
            }
        };

        processStep();
    }

    generateBlueprint() {
        const blueprint = this.createCustomBlueprint();
        this.displayBlueprint(blueprint);
        this.showSection('results-section');
    }

    createCustomBlueprint() {
        // Determine blueprint type based on project type
        const projectType = this.formData['project-type'] || 'Web Application';
        const baseBlueprint = projectType.includes('Mobile') ? 
            this.sampleBlueprints.mobileApp : this.sampleBlueprints.webService;

        // Customize blueprint based on user input
        const customBlueprint = {
            title: this.formData['idea-title'] || baseBlueprint.title,
            executiveSummary: this.generateCustomSummary(),
            problemAnalysis: {
                coreProblem: this.formData['problem-description'] || baseBlueprint.problemAnalysis.coreProblem,
                targetAudience: this.formData['target-audience'] || baseBlueprint.problemAnalysis.targetAudience,
                marketOpportunity: this.generateMarketOpportunity(),
                challenges: this.generateChallenges()
            },
            technologyStack: this.generateTechStack(),
            features: this.generateFeatures(),
            roadmap: this.generateRoadmap(),
            uiuxGuidelines: this.generateUIUXGuidelines(),
            knowledgeResources: this.generateKnowledgeResources(),
            deploymentStrategy: baseBlueprint.deploymentStrategy
        };

        return customBlueprint;
    }

    generateCustomSummary() {
        const title = this.formData['idea-title'] || 'Your Innovation Project';
        const description = this.formData['idea-description'] || 'A cutting-edge solution';
        const audience = this.formData['target-audience'] || 'modern users';
        
        return `${title} is ${description.toLowerCase()}. Designed for ${audience}, this platform aims to revolutionize the way people interact with technology and solve real-world problems.`;
    }

    generateMarketOpportunity() {
        const industry = this.formData['industry'] || 'Technology';
        const opportunities = {
            'Technology': '$2T global technology market with 8% annual growth',
            'Healthcare': '$350B digital healthcare market growing at 15% annually',
            'Finance': '$26.5B fintech market with 23% compound annual growth',
            'Education': '$80B edtech market expanding rapidly post-pandemic',
            'E-commerce': '$6.2T global e-commerce market with continued growth',
            'Entertainment': '$100B digital entertainment market',
            'Transportation': '$7T transportation industry undergoing digital transformation',
            'Food & Beverage': '$1.8T food industry embracing technology solutions',
            'Real Estate': '$3.7T real estate market adopting proptech solutions'
        };
        
        return opportunities[industry] || '$50B+ market opportunity with significant growth potential';
    }

    generateChallenges() {
        const challenges = [
            'User acquisition and retention',
            'Technology scalability',
            'Market competition',
            'Regulatory compliance',
            'Data privacy and security',
            'Integration complexity'
        ];
        
        return challenges.slice(0, 3);
    }

    generateTechStack() {
        const projectType = this.formData['project-type'] || 'Web Application';
        
        const stacks = {
            'Mobile App': {
                frontend: 'React Native or Flutter for cross-platform development',
                backend: 'Node.js with Express.js and MongoDB/PostgreSQL',
                apis: 'RESTful APIs with third-party integrations',
                infrastructure: 'AWS or Google Cloud with auto-scaling'
            },
            'Web Application': {
                frontend: 'React.js or Vue.js with modern UI framework',
                backend: 'Node.js/Python with database of choice',
                apis: 'GraphQL or REST APIs',
                infrastructure: 'Cloud deployment with CDN'
            },
            'Web Service/API': {
                backend: 'Python FastAPI or Node.js Express',
                database: 'PostgreSQL or MongoDB',
                caching: 'Redis for performance optimization',
                infrastructure: 'Microservices architecture on AWS/GCP'
            }
        };
        
        return stacks[projectType] || stacks['Web Application'];
    }

    generateFeatures() {
        const baseFeatures = [
            'User authentication and profiles',
            'Core functionality implementation',
            'Data management and storage',
            'Search and filtering capabilities',
            'Responsive design and mobile optimization',
            'Analytics and reporting dashboard'
        ];
        
        return baseFeatures;
    }

    generateRoadmap() {
        const timeline = this.formData['timeline'] || '6 months';
        
        if (timeline.includes('3 months')) {
            return [
                { phase: 'MVP (Month 1)', features: ['Core features', 'Basic UI', 'User authentication'] },
                { phase: 'Beta (Month 2)', features: ['Enhanced features', 'Testing', 'Bug fixes'] },
                { phase: 'Launch (Month 3)', features: ['Final polish', 'Deployment', 'User onboarding'] }
            ];
        } else if (timeline.includes('6 months')) {
            return [
                { phase: 'Foundation (Months 1-2)', features: ['Core architecture', 'Basic features', 'User system'] },
                { phase: 'Development (Months 3-4)', features: ['Advanced features', 'Integrations', 'Testing'] },
                { phase: 'Launch (Months 5-6)', features: ['Polish and optimization', 'Deployment', 'Marketing'] }
            ];
        } else {
            return [
                { phase: 'Planning (Months 1-3)', features: ['Detailed specifications', 'Architecture design', 'Team building'] },
                { phase: 'Development (Months 4-9)', features: ['Core development', 'Feature implementation', 'Testing'] },
                { phase: 'Launch (Months 10-12)', features: ['Beta testing', 'Final deployment', 'Marketing campaign'] }
            ];
        }
    }

    generateUIUXGuidelines() {
        const industry = this.formData['industry'] || 'Technology';
        
        const guidelines = {
            'Technology': ['Clean, modern interface', 'Tech-forward color scheme', 'Intuitive navigation'],
            'Healthcare': ['Professional, trustworthy design', 'Accessible color choices', 'Clear information hierarchy'],
            'Finance': ['Secure, professional appearance', 'Data-focused layouts', 'High contrast for readability'],
            'Education': ['Engaging, interactive elements', 'Age-appropriate design', 'Progress tracking visuals'],
            'E-commerce': ['Product-focused design', 'Easy checkout flow', 'Trust signals and reviews']
        };
        
        return guidelines[industry] || ['User-centered design', 'Responsive layouts', 'Consistent branding', 'Accessibility compliance'];
    }

    generateKnowledgeResources() {
        const projectType = this.formData['project-type'] || 'Web Application';
        const industry = this.formData['industry'] || 'Technology';
        
        const resources = [
            `${projectType} Development Best Practices`,
            `${industry} Industry Insights and Trends`,
            'User Experience Design Principles',
            'Modern Development Frameworks',
            'Scalability and Performance Optimization',
            'Business Strategy and Market Analysis'
        ];
        
        return resources;
    }

    displayBlueprint(blueprint) {
        const container = document.getElementById('blueprint-content');
        container.innerHTML = '';

        const sections = [
            { key: 'executiveSummary', title: 'Executive Summary', icon: '📋' },
            { key: 'problemAnalysis', title: 'Problem & Goal Analysis', icon: '🎯' },
            { key: 'technologyStack', title: 'Technology Stack', icon: '⚡' },
            { key: 'features', title: 'Feature Requirements', icon: '✨' },
            { key: 'roadmap', title: 'Development Roadmap', icon: '🗺️' },
            { key: 'uiuxGuidelines', title: 'UI/UX Guidelines', icon: '🎨' },
            { key: 'knowledgeResources', title: 'Knowledge Resources', icon: '📚' },
            { key: 'deploymentStrategy', title: 'Deployment Strategy', icon: '🚀' }
        ];

        sections.forEach(section => {
            const sectionElement = this.createBlueprintSection(section, blueprint[section.key]);
            container.appendChild(sectionElement);
        });

        // Make first section expanded by default
        const firstSection = container.querySelector('.section-header');
        const firstContent = container.querySelector('.section-content');
        if (firstSection && firstContent) {
            firstSection.classList.add('expanded');
            firstContent.classList.add('expanded');
        }
    }

    createBlueprintSection(section, data) {
        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'blueprint-section';

        const header = document.createElement('div');
        header.className = 'section-header';
        header.innerHTML = `
            <h3><span class="section-icon">${section.icon}</span> ${section.title}</h3>
            <span class="expand-icon">▼</span>
        `;

        const content = document.createElement('div');
        content.className = 'section-content';
        content.innerHTML = this.formatSectionContent(section.key, data);

        header.addEventListener('click', () => {
            header.classList.toggle('expanded');
            content.classList.toggle('expanded');
        });

        sectionDiv.appendChild(header);
        sectionDiv.appendChild(content);

        return sectionDiv;
    }

    formatSectionContent(key, data) {
        switch (key) {
            case 'executiveSummary':
                return `
                    <p>${data}</p>
                    <button class="copy-button" onclick="app.copyToClipboard('${data.replace(/'/g, "\\'")}')">📋 Copy</button>
                `;
            
            case 'problemAnalysis':
                return `
                    <div class="blueprint-grid">
                        <div class="blueprint-item">
                            <h4>Core Problem</h4>
                            <p>${data.coreProblem}</p>
                        </div>
                        <div class="blueprint-item">
                            <h4>Target Audience</h4>
                            <p>${data.targetAudience}</p>
                        </div>
                        <div class="blueprint-item">
                            <h4>Market Opportunity</h4>
                            <p>${data.marketOpportunity}</p>
                        </div>
                        <div class="blueprint-item">
                            <h4>Key Challenges</h4>
                            <ul>${data.challenges.map(challenge => `<li>${challenge}</li>`).join('')}</ul>
                        </div>
                    </div>
                `;
            
            case 'technologyStack':
                return `
                    <div class="blueprint-grid">
                        ${Object.entries(data).map(([tech, desc]) => `
                            <div class="blueprint-item">
                                <h4>${tech.charAt(0).toUpperCase() + tech.slice(1)}</h4>
                                <p>${desc}</p>
                            </div>
                        `).join('')}
                    </div>
                `;
            
            case 'features':
                return `
                    <ul>
                        ${data.map(feature => `<li>${feature}</li>`).join('')}
                    </ul>
                    <button class="copy-button" onclick="app.copyToClipboard('${data.join('\\n')}')">📋 Copy Features</button>
                `;
            
            case 'roadmap':
                return `
                    <div class="blueprint-grid">
                        ${data.map(phase => `
                            <div class="blueprint-item">
                                <h4>${phase.phase}</h4>
                                <ul>${phase.features.map(feature => `<li>${feature}</li>`).join('')}</ul>
                            </div>
                        `).join('')}
                    </div>
                `;
            
            case 'uiuxGuidelines':
                return `
                    <ul>
                        ${data.map(guideline => `<li>${guideline}</li>`).join('')}
                    </ul>
                `;
            
            case 'knowledgeResources':
                return `
                    <ul>
                        ${data.map(resource => `<li>${resource}</li>`).join('')}
                    </ul>
                `;
            
            case 'deploymentStrategy':
                return `
                    <div class="blueprint-grid">
                        ${Object.entries(data).map(([env, desc]) => `
                            <div class="blueprint-item">
                                <h4>${env.charAt(0).toUpperCase() + env.slice(1)}</h4>
                                <p>${desc}</p>
                            </div>
                        `).join('')}
                    </div>
                `;
            
            default:
                return `<p>${JSON.stringify(data)}</p>`;
        }
    }

    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showNotification('Copied to clipboard!', 'success');
        }).catch(() => {
            this.showNotification('Failed to copy', 'error');
        });
    }

    downloadPDF() {
        this.showNotification('PDF download feature coming soon!', 'info');
    }

    shareBlueprint() {
        if (navigator.share) {
            navigator.share({
                title: 'My Innovation Blueprint',
                text: 'Check out my project blueprint from Ideal!',
                url: window.location.href
            });
        } else {
            this.copyToClipboard(window.location.href);
            this.showNotification('Link copied to clipboard!', 'success');
        }
    }

    createAnother() {
        // Reset form data
        this.formData = {};
        this.currentStep = 1;
        
        // Reset form
        document.getElementById('idea-form').reset();
        this.showStep(1);
        this.updateProgress();
        
        // Show form section
        this.showSection('idea-form-section');
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-base);
            box-shadow: var(--shadow-lg);
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;
        
        if (type === 'success') {
            notification.style.borderColor = 'var(--color-success)';
            notification.style.color = 'var(--color-success)';
        } else if (type === 'error') {
            notification.style.borderColor = 'var(--color-error)';
            notification.style.color = 'var(--color-error)';
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Initialize the app
const app = new IdealApp();